﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        List<Error> lista;
        List<Error> listaSqlca;


        public Form1()
        {
            InitializeComponent();
            lista = new List<Error>();
            listaSqlca = new List<Error>(); 
            dgv1.Columns.Add("identificador", "Identificador_Cursor");
            dgv1.Columns.Add("linea", "Linea");

            dgv2.Columns.Add("identificador", "Identificador_Cursor");
            dgv2.Columns.Add("linea", "Linea");
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader archivo = File.OpenText("D://test.txt");
            List<String> tokensEncontrados = new List<string>();
            List<String> openEncontrados = new List<string>();
            List<String> closeEncontrados = new List<string>();
            List<String> openEncontradosExe = new List<string>();
            List<String> closeEncontradosExe = new List<string>();

            String[] palabrasReservadas =
            new String[11] { "LET", "insert", "delete", "INTO", "SELECT", "FROM", "WHERE",
            "PREPARE","END","FUNCTION","update"};

            String[] palabrasOpenCursor = new String[1]   { "OPEN" };
            String[] palabrasCerrarCursor = new String[1] { "CLOSE" };
            String[] palabrasExecute = new String[2] { "execute","into" };
           
            string caracter = null;
            string linea = null;
            int contadorLineas = 0;
            int cantidadTokens = 0;
            int errorLinea = 0;
            int auxLinea = 0;
            int n = 1;//SIRVE PARA AUMENTAR EL NUMERO DE LINEAS Y AYUDA EN BUSQUEDAS
            String aux1, aux2 = null;
            Boolean band = false;
            Boolean ban = false;
            int nn = 0;

          
            //RECONOCER LOS CURSORES QUE NO SE CIERREN
            while (!archivo.EndOfStream)
            {
                //Leer la línea:
                linea = archivo.ReadLine();
                
                contadorLineas++;

                nn = 0;  
                //BUSCA EL PRIMER CARACTER DE LA LINEA
                for (int m = 0; m < linea.Length; m++)
                {
                    if (linea.Substring(m, 1) != " " && linea.Substring(m, 1) != "\t")
                    {
                        caracter = linea.Substring(m, 1);
                    }
                }
                    //SI EL PRIMER CARACTER ES #, ENTONCES ES UN COMENTARIO Y SE DEBE 
                    //SALTAR LA LINEA
                    if(!caracter.Equals("#"))
                    {   //BUSCA LAS ABERTURAS DE CURSORES
                        openEncontrados = buscarIdentCursor(linea, palabrasOpenCursor);
                        for (int i = 0; i < openEncontrados.Count; i++)
                        {
                            Error cursor = new Error(contadorLineas, openEncontrados[i]);
                            lista.Add(cursor);
                        }
                        //BUSCA LA CLAUSULA CLOSE DE LOS CURSORES QUE YA ESTAN ABIERTOS
                        closeEncontrados = buscarIdentCursor(linea, palabrasCerrarCursor);
                        for (int i = 0; i < closeEncontrados.Count; i++)
                        {
                            aux1 = (closeEncontrados.ElementAt(i));
                            for (int j = 0; j < lista.Count; j++)
                            {
                                aux2 = lista.ElementAt(j).getIdentificador();
                                if (aux1.Equals(aux2, StringComparison.OrdinalIgnoreCase))
                                {
                                    lista.RemoveAt(j);

                                }
                            }
                        }

                        //BUSCA LOS EXECUTE QUE NO SON MANEJADOS CON SQLCA.SQLCODE y 
                        //LA PALABRA INTO
                        String id = null;
                        int num = 0;
                     
                        openEncontradosExe = buscarTokens(linea, palabrasExecute);
                     //##############################################################
                     if(openEncontradosExe.Count>0)
                     {  
                         if (openEncontradosExe.Count == 1)
                        {
                            if (openEncontradosExe[0].Equals("execute", StringComparison.OrdinalIgnoreCase))
                            {
                                if (linea.Substring(linea.Length - 1).Equals(",") ||
                                    (buscaPrimerCaracter(BuscaLinea(contadorLineas + 1)).Equals("into", StringComparison.OrdinalIgnoreCase)))
                                {
                                    if (existeToken(BuscaLinea(contadorLineas + 1), "INTO"))
                                    {
                                        Error cursor = new Error(contadorLineas + 1, "execute");
                                        listaSqlca.Add(cursor);

                                    }

                                 }
                                 else 
                                 {
                                    Error cursor = new Error(contadorLineas, "execute");
                                    listaSqlca.Add(cursor);
                                
                                 }

                            }
                        }
                        else
                        {   //CUANDO DOS EXECUTE EN DOS LINEAS CONSECUTIVAS ESTEN RELACIONADOS O CUANDO
                            //UN EXECUTE ASIGNA CON UN INTO EN UNA VARIABLE
                            if (openEncontradosExe.Count == 2)
                            {
                                if (openEncontradosExe[0].Equals("execute", StringComparison.OrdinalIgnoreCase))
                                {
                                    num++;


                                    if (openEncontradosExe[1].Equals("into", StringComparison.OrdinalIgnoreCase))
                                    {
                                        id = buscarIdentCursor(linea, "into");
                                        if (id != null)
                                        {
                                            band = true;
                                            n = 1;
                                            int l = 0;
                                            while (n < 3 && band)
                                            {
                                                if (buscarTokens(BuscaLinea(contadorLineas + n), "execute") != null)
                                                {   //EL PRIMER EXECUTE ESTA RELACIONADO CON EL SIGUIENTE EXECUTE
                                                    if (buscarTokens(BuscaLinea(contadorLineas + n), id) != null)
                                                    {
                                                        l = n;
                                                        num++;
                                                        band = false;
                                                    }
                                                }
                                                n++;
                                            }
                                            if (l == 0)
                                            {   //SI YA ESTA EL ERROR REGISTRADO, YA NO AGREGARLO NUEVAMENTE.
                                                if (!existeErrorLinea(listaSqlca, contadorLineas))
                                                {
                                                    Error cursor = new Error(contadorLineas, "execute");
                                                    listaSqlca.Add(cursor);
                                                    auxLinea = contadorLineas;
                                                }
                                            }
                                            if (num == 2)
                                            {
                                                Error cursor = new Error(contadorLineas + l, "execute");
                                                listaSqlca.Add(cursor);
                                                auxLinea = contadorLineas;
                                            }

                                        }
                                    }
                                }


                            }//FIN DE ENCONTRO TOKEN EXECUTE EN UNA LINEA, QUE ESTA RELACIONADA CON SU
                            //SIGUIENTE EXECUTE
                        }
                     //BUSCA LA CLAUSULA SQLCA DE LOS EXECUTE que no tienen SQLCA
                      closeEncontradosExe =new  List<String>();
                     ban = false;
                     n = 1;

                     while (n < 17 && !ban)
                     {
                         //SE BUSCA TOKENS QUE INDIQUEN QUE NO SE ENCONTRO SQLCA.SQLCODE
                         MessageBox.Show("  ###  " + (contadorLineas + n) + linea);
                         closeEncontradosExe = buscarTokens(BuscaLinea((contadorLineas + n)), palabrasReservadas);
                         if (closeEncontradosExe.Count > 0)
                         {
                             if ((existeToken(closeEncontradosExe, "prepare")) ||
                                 (existeToken(closeEncontradosExe, "EXECUTE")) ||
                                   ((existeToken(closeEncontradosExe, "let")) && (existeToken(closeEncontradosExe, "insert"))) ||
                                  ((existeToken(closeEncontradosExe, "end")) && (existeToken(closeEncontradosExe, "function"))) ||
                                    ((existeToken(closeEncontradosExe, "let")) && (existeToken(closeEncontradosExe, "insert"))) ||
                                (((existeToken(closeEncontradosExe, "let")) && (existeToken(closeEncontradosExe, "select"))) )
                                )
                             {
                                 MessageBox.Show( (contadorLineas + n) + linea);
                                 ban = true;
                                 nn++;

                             }
                         }
                         n++;

                     }

                     if (band == false && listaSqlca.Count > 0)
                     {
                       
                         listaSqlca.RemoveAt(buscaEnLista(listaSqlca,contadorLineas));
                     }

                    }//TERMINA DE ANALIZAR LA LINEA

                  }//SALTO DE LINEA SI EMPIEZA CON # 
                        
                
            }

            archivo.Close();
            for (int i=0; i < lista.Count;i++)
            {
                dgv1.Rows.Add(lista.ElementAt(i).getIdentificador(),lista.ElementAt(i).getLinea());
             
            }

            for (int i = 0; i < listaSqlca.Count; i++)
            {
                dgv2.Rows.Add(listaSqlca.ElementAt(i).getIdentificador(), listaSqlca.ElementAt(i).getLinea());

            }
        }

        public Boolean existeErrorLinea(List<Error> lista, int numero)
        {
            Boolean band = false;

            for (int i = 0; i < lista.Count;i++)
            {
                if (lista.ElementAt(i).getLinea() == numero)
                    band=true;
            }

            return band;  
        }

        public int buscaEnLista(List<Error> lista, int numero)
        {
             int aux = 0 ;

            for (int i = 0; i < lista.Count; i++)
            {
                if (lista.ElementAt(i).getLinea() == numero)
                    aux=i;
            }

            return aux;
        }

        public Boolean existeToken(List<String> lista, String ident)
        {
            Boolean band = false;

            for (int i = 0; i < lista.Count; i++)
            {
                if (lista.ElementAt(i).Equals(ident, StringComparison.OrdinalIgnoreCase))
                {
                    band = true;
                }

            }

            return band;
        }



        public String buscaPrimerCaracter(String linea) {
            String caracter = "";
            Boolean ban = false;
            int i = 0;
            while(i < linea.Length && !ban)
            {
                if (linea.Substring(i, 1) != " " && linea.Substring(i, 1) != "\t")
                {
                    caracter = linea.Substring(i, 1);
                    ban= true;
                }
                i++;
            }

            return caracter;
        }

        public String buscaPrimerToken(String linea)
        {
            String caracter = "";
            Boolean ban = false;
            int i = 0;
            while (i < linea.Length && !ban)
            {
                if (linea.Substring(i, 1) != " " && linea.Substring(i, 1) != "\t")
                {
                    caracter += linea.Substring(i, 1);
                    
                }

                //SI LA PALABRA ALMACENADA ES UN IDENTIFICADOR Y EL SIGUIENTE CARACTER 
                //ES UN ESPACIO EN BLANCO, LIMPIAR LA CADENA ALMACENADA HASTA EL MOMENTO
                if ((i + 1) < linea.Length)
                {
                    //SI EL VALOR QUE LE SIGUE AL VALOR ALMACENADO EN CARACTER ES UN ESPACIO

                    if ((linea.Substring(i + 1, 1).Equals(" ") && caracter != " "))
                        ban = true;
                }


                i++;
            }

            return caracter;
        }





        public List<String> buscarIdentCursor(String linea, String[] palabrasReservadas)
        {

            String caracter = "";
            String IdCursor = "";

            List<String> tokens = new List<String>();

            for (int i = 0; i < linea.Length; i++)
            {
                if (linea.Substring(i, 1) != " " && linea.Substring(i, 1) != "\t")
                {
                    caracter += linea.Substring(i, 1);
                }

               
                    if (existeToken(caracter, palabrasReservadas))
                    {

                        //BUSCA IDENTIFICADOR DEL CURSOR
                        //INICIO
                        for (int j = i + 1; j < linea.Length; j++)
                        {
                            if (linea.Substring(j, 1) != " " && linea.Substring(j, 1) != "\t")
                            {
                                IdCursor += linea.Substring(j, 1);
                            }
                        }//FIN DE BUSQUEDA DEL IDENTIFICADOR DEL CURSOR
                        tokens.Add(IdCursor);
                        caracter = "";

                    }

                    //SI LA PALABRA ALMACENADA ES UN IDENTIFICADOR Y EL SIGUIENTE CARACTER 
                    //ES UN ESPACIO EN BLANCO, LIMPIAR LA CADENA ALMACENADA HASTA EL MOMENTO
                    if ((i + 1) < linea.Length)
                    {
                        //SI EL VALOR QUE LE SIGUE AL VALOR ALMACENADO EN CARACTER ES UN ESPACIO

                        if ((linea.Substring(i + 1, 1).Equals(" ") && caracter != " ")|| (linea.Substring(i + 1, 1).Equals("=") && caracter != " "))
                        {
                            caracter = "";

                        }
                    }
            }

            return tokens;
        }


        public String buscarIdentCursor(String linea, String palabrasReservadas)
        {
            String caracter = "";
            String IdCursor = "";
            String token = "";

            for (int i = 0; i < linea.Length; i++)
            {
                if (linea.Substring(i, 1) != " " && linea.Substring(i, 1) != "\t")
                {
                    caracter += linea.Substring(i, 1);
                }

                if (existeToken(caracter, palabrasReservadas))
                {

                    //BUSCA IDENTIFICADOR DEL CURSOR
                    //INICIO
                    for (int j = i + 1; j < linea.Length; j++)
                    {
                        if (linea.Substring(j, 1) != " " && linea.Substring(j, 1) != "\t")
                        {
                            IdCursor += linea.Substring(j, 1);
                        }
                    }//FIN DE BUSQUEDA DEL IDENTIFICADOR DEL CURSOR
                    token=IdCursor;
                    caracter = "";

                }

                //SI LA PALABRA ALMACENADA ES UN IDENTIFICADOR Y EL SIGUIENTE CARACTER 
                //ES UN ESPACIO EN BLANCO, LIMPIAR LA CADENA ALMACENADA HASTA EL MOMENTO
                if ((i + 1) < linea.Length)
                {
                    //SI EL VALOR QUE LE SIGUE AL VALOR ALMACENADO EN CARACTER ES UN ESPACIO

                    if ((linea.Substring(i + 1, 1).Equals(" ") && caracter != " ") || (linea.Substring(i + 1, 1).Equals("=") && caracter != " "))
                    {
                        caracter = "";

                    }
                }

            }

            return token;
        }

        public Boolean existeToken(String cadena, String palabrasReservadas)
        {
            Boolean bandera = false;

            
                if (cadena.Equals(palabrasReservadas, StringComparison.OrdinalIgnoreCase))
                {
                    bandera = true;
                }
            

            return bandera;
        }


       public List<String> buscarTokens(String linea,String[] palabrasReservadas){
        
          String caracter ="";
          
          List<String> tokens =new List<String>();

            for(int i=0;i<linea.Length;i++)
            {
                if (linea.Substring(i, 1) != " " && linea.Substring(i, 1) != "\t")
                {
                  caracter += linea.Substring(i,1);
                }

                if (existeToken(caracter,palabrasReservadas))
                {
                    tokens.Add(caracter);
                    caracter = "";

                }
             
                  //SI LA PALABRA ALMACENADA ES UN IDENTIFICADOR Y EL SIGUIENTE CARACTER 
                  //ES UN ESPACIO EN BLANCO, LIMPIAR LA CADENA ALMACENADA HASTA EL MOMENTO
                    if ((i + 1) < linea.Length)
                    {   
                        //SI EL VALOR QUE LE SIGUE AL VALOR ALMACENADO EN CARACTER ES UN ESPACIO
                        if ((linea.Substring(i + 1, 1).Equals(" ") && caracter != " ") || (linea.Substring(i + 1, 1).Equals("=") && caracter != " "))
                        {
                            caracter = "";

                        }
                    }
                           
                
            }

          return tokens;
       
        }

       public String buscarTokens(String linea, String palabrasReservadas)
       {

           String caracter = "";

           String tokens = null;

           for (int i = 0; i < linea.Length; i++)
           {
               if (linea.Substring(i, 1) != " " && linea.Substring(i, 1) != "\t")
               {
                   caracter += linea.Substring(i, 1);
               }

               if (existeToken(caracter, palabrasReservadas))
               {
                   tokens = caracter;
                   caracter = "";

               }

               //SI LA PALABRA ALMACENADA ES UN IDENTIFICADOR Y EL SIGUIENTE CARACTER 
               //ES UN ESPACIO EN BLANCO, LIMPIAR LA CADENA ALMACENADA HASTA EL MOMENTO
               if ((i + 1) < linea.Length)
               {
                   //SI EL VALOR QUE LE SIGUE AL VALOR ALMACENADO EN CARACTER ES UN ESPACIO
                   if ((linea.Substring(i + 1, 1).Equals(" ") && caracter != " ") || (linea.Substring(i + 1, 1).Equals("=") && caracter != " "))
                   {
                       caracter = "";

                   }
               }


           }

           return tokens;

       }



        public Boolean existeToken(String cadena,String[] palabrasReservadas) 
        {
            Boolean bandera = false;
           
           for(int i=0;i<palabrasReservadas.Length;i++)
           {
              if(cadena.Equals(palabrasReservadas[i],StringComparison.OrdinalIgnoreCase))
                {
                  bandera=true;
                }
           }

            return bandera;
        }


        public String BuscaLinea(int numero)
        {
            //StreamReader archivo = File.OpenText("D://ef590_v3.4gl");
            StreamReader archivo = File.OpenText("D://test.txt");

            string linea = null;
            int i = 0;
            while (!archivo.EndOfStream)
            {
                //Leer la 5ta línea:
                linea = archivo.ReadLine();
                if (++i == numero) break;
            }
            archivo.Close();

            return linea;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }



    }

    public partial class Error{
        int linea;
        String identificador;

        public Error(int linea,String identificador) {
            this.linea = linea;
            this.identificador = identificador;
        
        }

        public int getLinea() {
            return this.linea;
        }

        public String getIdentificador() {
            return this.identificador;
        
        }

        public void setLinea(int linea) {
            this.linea = linea; 
        }

        public void setIdentificador(String identificador)
        {
            this.identificador = identificador;
        }
    }
}
